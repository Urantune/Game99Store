package WebBackEnd.repository;


import WebBackEnd.Entity.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;


@Repository
public interface EventRepository extends JpaRepository<Event, UUID> {

    Event findEventByType(String type);
    List<Event> findEventsByType(String type);


}
